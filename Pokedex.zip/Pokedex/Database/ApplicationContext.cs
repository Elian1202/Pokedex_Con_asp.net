﻿using Database.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options): base(options) { }

        public DbSet<Pokemon> pokemons { get; set; }

        public DbSet<Regiones> regiones { get; set; }

        public DbSet<Tipos> tipos { get; set; }
        public DbSet<Tipos> tipos2 { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region "tables"

            modelBuilder.Entity<Pokemon>().ToTable("Pokemons");
            modelBuilder.Entity<Regiones>().ToTable("Regiones");
            modelBuilder.Entity<Tipos>().ToTable("Tipos");
            #endregion

            #region "Primary keys"
            modelBuilder.Entity<Pokemon>()
                .HasKey(pokemons => pokemons.Id);
            modelBuilder.Entity<Tipos>()
                .HasKey(tipos => tipos.Id);
            modelBuilder.Entity<Regiones>()
                .HasKey(regiones => regiones.Id);
            #endregion

            #region "Telationships"
            modelBuilder.Entity<Tipos>().HasMany<Pokemon>(tipos => tipos.pokemons)
                .WithOne(pokemons => pokemons.tipos)
                .HasForeignKey(pokemons => pokemons.TipoPrimarioId)
                .OnDelete(DeleteBehavior.Cascade);

            //Estes no lleva delete porque daba error y no encontre solucion mas que estas.
            modelBuilder.Entity<Tipos>().HasMany<Pokemon>(tipos2 => tipos2.pokemons2)
                .WithOne(pokemons => pokemons.tipos2)
                .HasForeignKey(pokemons => pokemons.TipoSecundarioId);

            modelBuilder.Entity<Regiones>().HasMany<Pokemon>(regiones => regiones.pokemonsReg)
                .WithOne(pokemonsReg => pokemonsReg.regiones)
                .HasForeignKey(pokemonsReg => pokemonsReg.RegionId)
                .OnDelete(DeleteBehavior.Cascade);
            #endregion

            #region "Property configurations"
            #region "Pokemon"
            modelBuilder.Entity<Pokemon>().Property(pokemons => pokemons.Name).IsRequired();
            modelBuilder.Entity<Pokemon>().Property(pokemons => pokemons.TipoPrimarioId).IsRequired();
            modelBuilder.Entity<Pokemon>().Property(pokemons => pokemons.ImageUrl).IsRequired();
            modelBuilder.Entity<Pokemon>().Property(pokemons => pokemons.RegionId).IsRequired();
            #endregion

            #region"Tipos"
            modelBuilder.Entity<Tipos>()
                .Property(tipos => tipos.Name)
                .IsRequired().HasMaxLength(100);

            #endregion

            #region "Regiones"
            modelBuilder.Entity<Regiones>()
                .Property(regiones => regiones.Name)
                .IsRequired().HasMaxLength(100);

            #endregion

            #endregion

        }

    }
}
