﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database.Models
{
    public class Tipos
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public string TipoPoke { get; set; }


        //Navigation propety
        public ICollection<Pokemon> pokemons { get; set; }

        public ICollection<Pokemon> pokemons2 { get; set; }

    }
}
