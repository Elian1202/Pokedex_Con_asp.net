﻿using Application.Services;
using Application.ViewModels;
using Database;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Pokedex.Controllers
{
    public class TiposController : Controller
    {
        private readonly TiposService _tiposService;

        public TiposController(ApplicationContext dbContex)
        {
            _tiposService = new(dbContex);
        }
        public async Task<IActionResult> Index()
        {
            return View(await _tiposService.GeyAllViewModel());
        }

        public IActionResult Create()
        {
            return View("SaveTipos", new SaveTiposViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Create(SaveTiposViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("SaveTipos", vm);
            }
            await _tiposService.Add(vm);
            return RedirectToRoute(new { controller = "Tipos", action = "Index" });
        }

        public async Task<IActionResult> Edit(int id)
        {

            return View("SaveTipos", await _tiposService.GetByIdSaveTiposViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(SaveTiposViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("SaveTipos", vm);
            }

            await _tiposService.Update(vm);
            return RedirectToRoute(new { controller = "Tipos", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {

            return View(await _tiposService.GetByIdSaveTiposViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {

            await _tiposService.Delete(id);
            return RedirectToRoute(new { controller = "Tipos", action = "Index" });
        }
    }
}
