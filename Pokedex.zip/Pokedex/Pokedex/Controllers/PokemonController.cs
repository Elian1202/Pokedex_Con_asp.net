﻿using Application.Services;
using Application.ViewModels;
using Database;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Pokedex.Controllers
{
    public class PokemonController : Controller
    {
        private readonly PokemonService _pokemonService;
        private readonly TiposService _tiposService;
        private readonly RegionesService _regionesService;

        public PokemonController(ApplicationContext dbContex)
        {
            _pokemonService = new(dbContex);
            _tiposService = new(dbContex);
            _regionesService = new(dbContex);
        }
        public async Task<IActionResult> Index()
        {
            return View(await _pokemonService.GeyAllViewModel());
        }

        public async Task<IActionResult>  Create()
        {
            SavePokemonViewModel vm = new();
            vm.TiposLis = await _tiposService.GeyAllViewModel();
            vm.RegionLis = await _regionesService.GeyAllViewModel();
            return View("SavePokemon",vm);
        }

        [HttpPost]
        public async Task<IActionResult> Create(SavePokemonViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.RegionLis = await _regionesService.GeyAllViewModel();
                vm.TiposLis = await _tiposService.GeyAllViewModel();
                return View("SavePokemon",vm);
            }
            await _pokemonService.Add(vm);
            return RedirectToRoute(new { controller = "Pokemon", action = "Index" });
        }

        public async Task<IActionResult> Edit(int id)
        {
            SavePokemonViewModel vm = await _pokemonService.GetByIdSavePokemonViewModel(id);
            vm.RegionLis = await _regionesService.GeyAllViewModel();
            vm.TiposLis = await _tiposService.GeyAllViewModel();
            return View("SavePokemon", vm);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(SavePokemonViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.RegionLis = await _regionesService.GeyAllViewModel();
                vm.TiposLis = await _tiposService.GeyAllViewModel();
                return View("SavePokemon", vm);
            }

            await _pokemonService.Update(vm);
            return RedirectToRoute(new { controller = "Pokemon", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {

            return View(await _pokemonService.GetByIdSavePokemonViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
           
            await _pokemonService.Delete(id);
            return RedirectToRoute(new { controller = "Pokemon", action = "Index" });
        }
    }
}
