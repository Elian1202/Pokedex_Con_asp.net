﻿using Application.Services;
using Application.ViewModels;
using Database;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Pokedex.Controllers
{
    public class RegionController : Controller
    {
        private readonly RegionesService _regionesService;

        public RegionController(ApplicationContext dbContex)
        {
            _regionesService = new(dbContex);
        }
        public async Task<IActionResult> Index()
        {
            return View(await _regionesService.GeyAllViewModel());
        }

        public IActionResult Create()
        {
            return View("SaveRegion", new SaveRegionesViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Create(SaveRegionesViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("SaveRegion", vm);
            }
            await _regionesService.Add(vm);
            return RedirectToRoute(new { controller = "Region", action = "Index" });
        }

        public async Task<IActionResult> Edit(int id)
        {

            return View("SaveRegion", await _regionesService.GetByIdSaveRegionesViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(SaveRegionesViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("SaveRegion", vm);
            }

            await _regionesService.Update(vm);
            return RedirectToRoute(new { controller = "Region", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {

            return View(await _regionesService.GetByIdSaveRegionesViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {

            await _regionesService.Delete(id);
            return RedirectToRoute(new { controller = "Region", action = "Index" });
        }
    }
}
