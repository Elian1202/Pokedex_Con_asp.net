﻿using Application.Services;
using Application.ViewModels;
using Database;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Pokedex.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Pokedex.Controllers
{
    public class HomeController : Controller
    {
        private readonly PokemonService _pokemonService;
        private readonly RegionesService _regionesService;
        private readonly TiposService _tiposService;

        public HomeController(ApplicationContext dbContex)
        {
            _pokemonService = new(dbContex);
            _tiposService = new(dbContex);
            _regionesService = new(dbContex);
        }

        public async Task<IActionResult> Index(FiltroPokemon vm)
        {
            ViewBag.tiposs = await _tiposService.GeyAllViewModel();
            ViewBag.regiones = await _regionesService.GeyAllViewModel();
            return View(await _pokemonService.GeyAllViewModelwhitFiltros(vm));
        }

        //public async Task<IActionResult> Index2()
        //{
        //    return View(await _regionesService.GeyAllViewModel());
        //}
        //public async Task<IActionResult> Index3()
        //{
        //    return View(await _tiposService.GeyAllViewModel());
        //}


        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}
    }
}
