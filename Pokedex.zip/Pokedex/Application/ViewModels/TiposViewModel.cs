﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModels
{
    public class TiposViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public string TipoPoke { get; set; }

        public int PokemonQuantity { get; set; }
        public int PokemonQuantity2 { get; set; }
    }
}
