﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModels
{
    public class PokemonViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public string ImageUrl { get; set; }



        public string RegionName { get; set; }

        public string TipoPrimarioName { get; set; }

        public string TipoSecundarioName { get; set; }
        public int TiposId { get; set; }
        public int RegionesId { get; set; }
    }
}
