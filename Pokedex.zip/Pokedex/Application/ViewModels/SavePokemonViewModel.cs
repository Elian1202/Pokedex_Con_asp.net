﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModels
{
    public class SavePokemonViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Debe Colocar el nombre del pokemon")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Debe Colocar la Descripcion del pokemon")]
        public string Descripcion { get; set; }
        [Required(ErrorMessage = "Debe Colocar la Url de la imagen del pokemon")]
        public string ImageUrl { get; set; }
        [Range(1, int.MaxValue,ErrorMessage = "Debe Colocar la region del pokemon")]
        public int RegionId { get; set; }

        [Range(1, int.MaxValue,ErrorMessage = "Debe Colocar el primer tipo del pokemon")]
        public int TipoPrimarioId { get; set; }

        [Range(1, int.MaxValue,ErrorMessage = "Debe Colocar el segundo tipo del pokemon")]
        public int TipoSecundarioId { get; set; }



        public List<TiposViewModel>TiposLis { get; set; }
        public List<RegionesViewModel> RegionLis { get; set; }


    }
}
