﻿using Database;
using Database.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Repositorio
{
    public class RegionRepositorio
    {
        private readonly ApplicationContext _dbContex;

        public RegionRepositorio(ApplicationContext dbContex)
        {
            _dbContex = dbContex;
        }   

        public async Task AddAsync(Regiones regiones)
        {
            await _dbContex.regiones.AddAsync(regiones);
            await _dbContex.SaveChangesAsync();
        }

        public async Task UpdateAsync(Regiones regiones)
        {
            _dbContex.Entry(regiones).State = EntityState.Modified;
            await _dbContex.SaveChangesAsync();
        }

        public async Task DeleteAsync(Regiones regiones)
        {
            _dbContex.Set<Regiones>().Remove(regiones);
            await _dbContex.SaveChangesAsync();
        }

        public async Task<List<Regiones>> GetAllAsync()
        {
            return await _dbContex.Set<Regiones>().ToListAsync();
        }
        public async Task<List<Regiones>> GetAllwhitIncludeAsync()
        {

            return await _dbContex.Set<Regiones>().Include(i => i.pokemonsReg).ToListAsync();
        }

        public async Task<Regiones> GetByIdAsync(int id)
        {
            return await _dbContex.Set<Regiones>().FindAsync(id);
        }
    }
}
