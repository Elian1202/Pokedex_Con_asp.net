﻿using Database;
using Database.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Repositorio
{
    public class TiposRepositorio
    {
        private readonly ApplicationContext _dbContex;

        public TiposRepositorio(ApplicationContext dbContex)
        {
            _dbContex = dbContex;
        }   

        public async Task AddAsync(Tipos tipos)
        {
            await _dbContex.tipos.AddAsync(tipos);
            await _dbContex.SaveChangesAsync();
        }

        public async Task UpdateAsync(Tipos tipos)
        {
            _dbContex.Entry(tipos).State = EntityState.Modified;
            await _dbContex.SaveChangesAsync();
        }

        public async Task DeleteAsync(Tipos tipos)
        {
            _dbContex.Set<Tipos>().Remove(tipos);
            await _dbContex.SaveChangesAsync();
        }

        public async Task<List<Tipos>> GetAllAsync()
        {
            return await _dbContex.Set<Tipos>().ToListAsync();
        }

        public async Task<List<Tipos>> GetAllwhitIncludeAsync()
        {

            return await _dbContex.Set<Tipos>().Include(i => i.pokemons).Include(i2 => i2.pokemons2).ToListAsync();
        }

        public async Task<Tipos> GetByIdAsync(int id)
        {
            return await _dbContex.Set<Tipos>().FindAsync(id);
        }
    }
}
