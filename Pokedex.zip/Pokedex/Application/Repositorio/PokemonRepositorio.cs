﻿using Database;
using Database.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Repositorio
{
    public class PokemonRepositorio
    {
        private readonly ApplicationContext _dbContex;

        public PokemonRepositorio(ApplicationContext dbContex)
        {
            _dbContex = dbContex;
        }   

        public async Task AddAsync(Pokemon pokemon)
        {
            await _dbContex.pokemons.AddAsync(pokemon);
            await _dbContex.SaveChangesAsync();
        }

        public async Task UpdateAsync(Pokemon pokemon)
        {
            _dbContex.Entry(pokemon).State = EntityState.Modified;
            await _dbContex.SaveChangesAsync();
        }

        public async Task DeleteAsync(Pokemon pokemon)
        {
            _dbContex.Set<Pokemon>().Remove(pokemon);
            await _dbContex.SaveChangesAsync();
        }

        public async Task<List<Pokemon>> GetAllAsync()
        {
            return await _dbContex.Set<Pokemon>().ToListAsync();
        }
        public async Task<List<Pokemon>> GetAllwhitIncludeAsync()
        {

            return await _dbContex.Set<Pokemon>().Include(i => i.tipos).Include(t=> t.regiones).Include(t2 => t2.tipos2).ToListAsync();
        }

        public async Task<Pokemon> GetByIdAsync(int id)
        {
            return await _dbContex.Set<Pokemon>().FindAsync(id);
        }
    }
}
