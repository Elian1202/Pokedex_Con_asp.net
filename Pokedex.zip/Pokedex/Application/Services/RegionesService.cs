﻿using Application.Repositorio;
using Application.ViewModels;
using Database;
using Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class RegionesService
    {
        private readonly RegionRepositorio _regionRepositorio;

        public RegionesService(ApplicationContext dbContex)
        {
            _regionRepositorio = new(dbContex);
        }

        public async Task Update(SaveRegionesViewModel vm)
        {
            Regiones regiones = new();
            regiones.Id = vm.Id;
            regiones.Name = vm.Name;
            regiones.Descripcion = vm.Descripcion;
            await _regionRepositorio.UpdateAsync(regiones);
        }

        public async Task Add(SaveRegionesViewModel vm)
        {
            Regiones regiones = new();
            regiones.Name = vm.Name;
            regiones.Descripcion = vm.Descripcion;
            await _regionRepositorio.AddAsync(regiones);
        }

        public async Task Delete(int id)
        {
            var regiones = await _regionRepositorio.GetByIdAsync(id);
            await _regionRepositorio.DeleteAsync(regiones);
        }

        public async Task<SaveRegionesViewModel> GetByIdSaveRegionesViewModel(int id)
        {
            var region = await _regionRepositorio.GetByIdAsync(id);

            SaveRegionesViewModel vm = new();
            vm.Id = region.Id;
            vm.Name = region.Name;
            vm.Descripcion = region.Descripcion;
            return vm;
        }

        public async Task<List<RegionesViewModel>> GeyAllViewModel()
        {
            var regionesList = await _regionRepositorio.GetAllwhitIncludeAsync();
            return regionesList.Select(Regiones => new RegionesViewModel
            {
                Name = Regiones.Name,
                Descripcion = Regiones.Descripcion,
                Id = Regiones.Id,
                PokemonRegQuiantity = Regiones.pokemonsReg.Count()
            }).ToList();
        }
    }
}
