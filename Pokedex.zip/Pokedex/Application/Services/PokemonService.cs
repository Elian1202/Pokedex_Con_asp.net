﻿using Application.Repositorio;
using Application.ViewModels;
using Database;
using Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class PokemonService
    {
        private readonly PokemonRepositorio _pokemonRepositorio;

        public PokemonService(ApplicationContext dbContex)
        {
            _pokemonRepositorio = new(dbContex);
        }

        public async Task Update(SavePokemonViewModel vm)
        {
            Pokemon pokemon = new();
            pokemon.Id = vm.Id;
            pokemon.Name = vm.Name;
            pokemon.Descripcion = vm.Descripcion;
            pokemon.ImageUrl = vm.ImageUrl; 
            pokemon.TipoPrimarioId = vm.TipoPrimarioId;
            pokemon.TipoSecundarioId = vm.TipoSecundarioId;
            pokemon.RegionId = vm.RegionId;
            await _pokemonRepositorio.UpdateAsync(pokemon);
        }

        public async Task Add(SavePokemonViewModel vm)
        {
            Pokemon pokemon = new();
            pokemon.Name = vm.Name;
            pokemon.Descripcion = vm.Descripcion;
            pokemon.ImageUrl = vm.ImageUrl;
            pokemon.TipoPrimarioId = vm.TipoPrimarioId;
            pokemon.TipoSecundarioId = vm.TipoSecundarioId;
            pokemon.RegionId = vm.RegionId;
            await _pokemonRepositorio.AddAsync(pokemon);
        }

        public async Task Delete(int id)
        {
            var pokemon = await _pokemonRepositorio.GetByIdAsync(id);
            await _pokemonRepositorio.DeleteAsync(pokemon);
        }

        public async Task<SavePokemonViewModel> GetByIdSavePokemonViewModel(int id)
        {
            var pokemon = await _pokemonRepositorio.GetByIdAsync(id);

            SavePokemonViewModel vm = new();
            vm.Id = pokemon.Id;
            vm.Name = pokemon.Name;
            vm.Descripcion = pokemon.Descripcion;
            vm.ImageUrl = pokemon.ImageUrl;
            vm.TipoPrimarioId = pokemon.TipoPrimarioId;
            vm.TipoSecundarioId = pokemon.TipoSecundarioId;
            vm.RegionId = pokemon.RegionId;
            return vm;
        }

        public async Task<List<PokemonViewModel>> GeyAllViewModel()
        {
            var pokemonList = await _pokemonRepositorio.GetAllwhitIncludeAsync();
            return pokemonList.Select(Pokemon => new PokemonViewModel
            {
                Name = Pokemon.Name,
                Descripcion = Pokemon.Descripcion,
                Id = Pokemon.Id,
                ImageUrl = Pokemon.ImageUrl,
                RegionName = Pokemon.regiones.Name,
                TipoPrimarioName = Pokemon.tipos.Name,
                TipoSecundarioName = Pokemon.tipos2.Name
            }).ToList();
        }
        public async Task<List<PokemonViewModel>> GeyAllViewModelwhitFiltros(FiltroPokemon filter)
        {
            var pokemonList = await _pokemonRepositorio.GetAllwhitIncludeAsync();
            var ListViewModels = pokemonList.Select(Pokemon => new PokemonViewModel
            {
                Name = Pokemon.Name,
                Descripcion = Pokemon.Descripcion,
                Id = Pokemon.Id,
                ImageUrl = Pokemon.ImageUrl,
                RegionName = Pokemon.regiones.Name,
                TipoPrimarioName = Pokemon.tipos.Name,
                TipoSecundarioName = Pokemon.tipos2.Name,
                TiposId = Pokemon.tipos2.Id,
                RegionesId = Pokemon.regiones.Id,
            }).ToList();

            if(filter.TiposId != null)
            {
                ListViewModels = ListViewModels.Where(pokemon => pokemon.TiposId == filter.TiposId.Value).ToList();
            }
            if (filter.RegionesId != null)
            {
                ListViewModels = ListViewModels.Where(pokemon => pokemon.RegionesId == filter.RegionesId.Value).ToList();
            }

            return ListViewModels;
        }
    }
}
