﻿using Application.Repositorio;
using Application.ViewModels;
using Database;
using Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class TiposService
    {
        private readonly TiposRepositorio _tiposRepositorio;

        public TiposService(ApplicationContext dbContex)
        {
            _tiposRepositorio = new(dbContex);
        }

        public async Task Update(SaveTiposViewModel vm)
        {
            Tipos tipos = new();
            tipos.Id = vm.Id;
            tipos.Name = vm.Name;
            tipos.Descripcion = vm.Descripcion;
            tipos.TipoPoke = vm.TipoPoke;
            await _tiposRepositorio.UpdateAsync(tipos);
        }

        public async Task Add(SaveTiposViewModel vm)
        {
            Tipos tipos = new();
            tipos.Name = vm.Name;
            tipos.Descripcion = vm.Descripcion;
            tipos.TipoPoke = vm.TipoPoke;
            await _tiposRepositorio.AddAsync(tipos);
        }

        public async Task Delete(int id)
        {
            var tipos = await _tiposRepositorio.GetByIdAsync(id);
            await _tiposRepositorio.DeleteAsync(tipos);
        }

        public async Task<SaveTiposViewModel> GetByIdSaveTiposViewModel(int id)
        {
            var tiposs = await _tiposRepositorio.GetByIdAsync(id);

            SaveTiposViewModel vm = new();
            vm.Id = tiposs.Id;
            vm.Name = tiposs.Name;
            vm.Descripcion = tiposs.Descripcion;
            vm.TipoPoke = tiposs.TipoPoke.ToString();
            return vm;
        }

        public async Task<List<TiposViewModel>> GeyAllViewModel()
        {
            var tiposList = await _tiposRepositorio.GetAllwhitIncludeAsync();
            return tiposList.Select(Tipos => new TiposViewModel
            {
                Name = Tipos.Name,
                Descripcion = Tipos.Descripcion,
                Id = Tipos.Id,
                TipoPoke=Tipos.TipoPoke,
                PokemonQuantity = Tipos.pokemons.Count(),
                PokemonQuantity2 = Tipos.pokemons2.Count()   
            }).ToList();
        }
    }
}
